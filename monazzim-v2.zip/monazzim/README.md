# منظّم — AI Productivity OS

> مشروع Portfolio قوي يجمع Eisenhower Matrix + Pomodoro + AI Coach + Analytics + Streaks + Daily Reflection

## Features
- **Eisenhower Matrix** — 4 quadrants لتنظيم المهام (عاجل/مهم)
- **Pomodoro Timer** — مؤقت دائري مع سجل الجلسات
- **AI Coach** — محادثة مع Claude يحلّل مهامك ويقترح أولويات
- **Analytics** — رسوم بيانية لنسب الإنجاز والأداء الأسبوعي
- **Streaks & Badges** — نظام نقاط وإنجازات يحفّزك
- **Daily Reflection** — تأمل يومي بتحليل AI
- **آية / اقتباس يومي** — من القرآن والأحاديث والحكم
- **D3 Background** — خلفية animated تتكيّف مع الـ dark/light mode
- **localStorage** — يحفظ كل حاجة محلياً بدون backend

## Stack
- React 18 + Vite
- D3.js (background animation)
- Anthropic Claude API (AI Coach + Reflection Analysis)
- CSS Variables (theming)
- localStorage (persistence)

## Setup

```bash
npm install
npm run dev
```

## Project Structure
```
src/
  App.jsx                    # Main app + navigation + shared state
  main.jsx                   # Entry point
  index.css                  # Global styles + Cairo font
  components/
    D3Background.jsx         # Animated SVG background
    EisenhowerMatrix.jsx     # Core 4-quadrant task manager
    PomodoroTimer.jsx        # Circular timer + session log
    AICoach.jsx              # Chat with Claude about your tasks
    Analytics.jsx            # Donut chart + bar chart + KPIs
    Streaks.jsx              # Streak counter + badges system
    DailyReflection.jsx      # Daily journaling + AI insight
    DailyQuote.jsx           # Quranic verse / quote of the day
```

## Portfolio Value
يبيّن كفاءة في:
- React State Management (shared state, localStorage)
- Component Architecture (8 components منظّمة)
- AI API Integration (Anthropic Claude)
- Data Visualization (D3, SVG charts)
- UX/UI Design (RTL, dark mode, animations)
- Arabic Localization
