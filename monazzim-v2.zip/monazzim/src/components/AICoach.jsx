import { useState } from "react";

const SUGGESTIONS = [
  "حلّلي مهامي وقولي أيها الأهم",
  "عندي كتير مهام، ساعدني أرتّبها",
  "اقترحلي استراتيجية للأسبوع دا",
  "إيه أكتر حاجة المفروض أركّز عليها دلوقتي؟",
];

export default function AICoach({ tasks, streak, completedToday }) {
  const [messages, setMessages] = useState([
    { role: "assistant", text: "أهلاً! أنا AI Coach بتاعك. قولّي إيه اللي شاغل بالك؟ ممكن أساعدك ترتّب مهامك وتبقى أكتر إنتاجية. 🤖" }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  function buildContext() {
    const qs = ["q1","q2","q3","q4"];
    const labels = ["عاجل ومهم","مهم مش عاجل","عاجل مش مهم","مش مهم ومش عاجل"];
    return qs.map((q, i) => `${labels[i]}: ${(tasks[q]||[]).map(t=>(t.done?"✅ ":"◻ ")+t.text).join(" | ")||"فارغ"}`).join("\n");
  }

  async function send(text) {
    const msg = text || input.trim();
    if (!msg) return;
    setInput("");
    const userMsg = { role: "user", text: msg };
    setMessages(prev => [...prev, userMsg]);
    setLoading(true);

    const history = [...messages, userMsg].map(m => ({ role: m.role === "assistant" ? "assistant" : "user", content: m.text }));

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          system: `أنت AI Coach متخصص في الإنتاجية ومصفوفة أيزنهاور. تتكلم بالعربي المصري بشكل ودّي ومختصر.
مهام المستخدم الحالية:
${buildContext()}
إنجازات: streak ${streak.count} يوم، أكمل ${completedToday.count} مهمة اليوم.
قدّم نصائح عملية ومحددة. استخدم emoji باعتدال. لا تطوّل.`,
          messages: history,
        }),
      });
      const data = await res.json();
      const reply = data.content?.map(b => b.text || "").join("") || "حدث خطأ، حاول تاني.";
      setMessages(prev => [...prev, { role: "assistant", text: reply }]);
    } catch {
      setMessages(prev => [...prev, { role: "assistant", text: "في مشكلة في الاتصال، حاول تاني." }]);
    }
    setLoading(false);
  }

  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 260px", gap: 16, alignItems: "start" }}>
      <div style={{ background: "var(--color-background-primary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: 16, overflow: "hidden", display: "flex", flexDirection: "column", height: 560 }}>
        <div style={{ padding: "14px 16px", borderBottom: "0.5px solid var(--color-border-tertiary)", display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 32, height: 32, borderRadius: "50%", background: "#7F77DD", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>🤖</div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 500 }}>AI Coach</div>
            <div style={{ fontSize: 11, color: "#1D9E75" }}>● متصل</div>
          </div>
        </div>

        <div style={{ flex: 1, overflowY: "auto", padding: 16, display: "flex", flexDirection: "column", gap: 10 }}>
          {messages.map((m, i) => (
            <div key={i} style={{ display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start" }}>
              <div style={{
                maxWidth: "80%", padding: "10px 14px", borderRadius: m.role === "user" ? "16px 16px 4px 16px" : "16px 16px 16px 4px",
                background: m.role === "user" ? "#7F77DD" : "var(--color-background-secondary)",
                color: m.role === "user" ? "#fff" : "var(--color-text-primary)",
                border: m.role === "assistant" ? "0.5px solid var(--color-border-tertiary)" : "none",
                fontSize: 13, lineHeight: 1.6, whiteSpace: "pre-wrap",
              }}>{m.text}</div>
            </div>
          ))}
          {loading && (
            <div style={{ display: "flex", gap: 5, padding: "10px 14px", background: "var(--color-background-secondary)", borderRadius: "16px 16px 16px 4px", width: "fit-content", border: "0.5px solid var(--color-border-tertiary)" }}>
              {[0,1,2].map(i => <div key={i} style={{ width: 6, height: 6, borderRadius: "50%", background: "#7F77DD", animation: `bounce 1.2s ${i*0.2}s infinite` }} />)}
            </div>
          )}
        </div>

        <div style={{ padding: 12, borderTop: "0.5px solid var(--color-border-tertiary)", display: "flex", gap: 8 }}>
          <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === "Enter" && send()}
            placeholder="اكتب سؤالك..."
            style={{ flex: 1, padding: "8px 12px", border: "0.5px solid var(--color-border-tertiary)", borderRadius: 24, background: "var(--color-background-secondary)", color: "var(--color-text-primary)", fontSize: 13, fontFamily: "var(--font-sans)", outline: "none" }} />
          <button onClick={() => send()} disabled={loading} style={{ width: 36, height: 36, borderRadius: "50%", border: "none", background: "#7F77DD", color: "#fff", cursor: "pointer", fontSize: 16, display: "flex", alignItems: "center", justifyContent: "center" }}>↑</button>
        </div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        <div style={{ background: "var(--color-background-primary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: 16, padding: 16 }}>
          <h3 style={{ fontSize: 13, fontWeight: 500, margin: "0 0 10px", color: "var(--color-text-secondary)" }}>💡 اقتراحات سريعة</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {SUGGESTIONS.map((s, i) => (
              <button key={i} onClick={() => send(s)} style={{ padding: "8px 10px", borderRadius: 8, border: "0.5px solid var(--color-border-tertiary)", background: "var(--color-background-secondary)", color: "var(--color-text-primary)", fontSize: 12, cursor: "pointer", textAlign: "right", fontFamily: "var(--font-sans)", lineHeight: 1.4, transition: "background 0.15s" }}>
                {s}
              </button>
            ))}
          </div>
        </div>

        <div style={{ background: "#EEEDFE", border: "0.5px solid #7F77DD30", borderRadius: 16, padding: 16 }}>
          <h3 style={{ fontSize: 13, fontWeight: 500, margin: "0 0 10px", color: "#3C3489" }}>📊 ملخص سريع</h3>
          {[
            ["🔥 Streak", streak.count + " يوم"],
            ["⚡ اليوم", completedToday.count + " مهمة"],
            ["🏅 Badges", streak.badges?.length || 0],
          ].map(([label, val], i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "5px 0", borderBottom: i < 2 ? "0.5px solid #7F77DD20" : "none", fontSize: 13 }}>
              <span style={{ color: "#3C3489" }}>{label}</span>
              <strong style={{ color: "#7F77DD" }}>{val}</strong>
            </div>
          ))}
        </div>
      </div>
      <style>{`@keyframes bounce{0%,80%,100%{transform:translateY(0)}40%{transform:translateY(-6px)}}`}</style>
    </div>
  );
}
