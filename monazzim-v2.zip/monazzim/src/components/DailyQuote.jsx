import { useState, useEffect } from "react";

const QUOTES = [
  { text: "﴿وَمَن يَتَوَكَّلْ عَلَى اللَّهِ فَهُوَ حَسْبُهُ﴾", source: "سورة الطلاق" },
  { text: "﴿إِنَّ مَعَ الْعُسْرِ يُسْرًا﴾", source: "سورة الشرح" },
  { text: "﴿وَقُل رَّبِّ زِدْنِي عِلْمًا﴾", source: "سورة طه" },
  { text: "المؤمن القوي خير وأحب إلى الله من المؤمن الضعيف", source: "صحيح مسلم" },
  { text: "خير الناس أنفعهم للناس", source: "حديث شريف" },
  { text: "اعقلها وتوكّل", source: "حديث شريف" },
  { text: "النجاح ليس نهاية الطريق، والفشل ليس نهاية المشوار", source: "ونستون تشرشل" },
  { text: "الوقت كالسيف إن لم تقطعه قطعك", source: "مثل عربي" },
  { text: "لا تؤجّل عمل اليوم إلى الغد", source: "حكمة" },
  { text: "ابدأ بما تستطيع، بما عندك، من حيث أنت", source: "آرثر آشي" },
];

export default function DailyQuote({ compact }) {
  const [quote, setQuote] = useState(null);
  const [show, setShow] = useState(false);

  useEffect(() => {
    const idx = new Date().getDate() % QUOTES.length;
    setQuote(QUOTES[idx]);
  }, []);

  if (!quote) return null;

  if (compact) {
    return (
      <div style={{ position: "relative" }}>
        <button
          onClick={() => setShow(s => !s)}
          style={{ padding: "4px 10px", borderRadius: 20, border: "0.5px solid var(--color-border-tertiary)", background: "var(--color-background-secondary)", color: "var(--color-text-secondary)", fontSize: 12, cursor: "pointer", fontFamily: "var(--font-sans)", display: "flex", alignItems: "center", gap: 4 }}
        >
          ✨ آية اليوم
        </button>
        {show && (
          <div style={{
            position: "absolute", top: "calc(100% + 8px)", left: "50%", transform: "translateX(-50%)",
            width: 260, background: "var(--color-background-primary)", border: "0.5px solid var(--color-border-tertiary)",
            borderRadius: 12, padding: 14, boxShadow: "0 8px 24px rgba(0,0,0,0.12)", zIndex: 100,
          }}>
            <p style={{ fontSize: 14, lineHeight: 1.8, margin: "0 0 8px", color: "var(--color-text-primary)", textAlign: "center", fontWeight: 500 }}>{quote.text}</p>
            <p style={{ fontSize: 11, color: "var(--color-text-secondary)", textAlign: "center", margin: 0 }}>— {quote.source}</p>
          </div>
        )}
      </div>
    );
  }

  return (
    <div style={{ background: "linear-gradient(135deg, #EEEDFE, #E1F5EE)", border: "0.5px solid #7F77DD30", borderRadius: 12, padding: "14px 18px", textAlign: "center" }}>
      <div style={{ fontSize: 11, color: "#7F77DD", fontWeight: 500, marginBottom: 8, textTransform: "uppercase", letterSpacing: "0.05em" }}>✨ آية / اقتباس اليوم</div>
      <p style={{ fontSize: 15, lineHeight: 1.8, margin: "0 0 6px", color: "var(--color-text-primary)", fontWeight: 500 }}>{quote.text}</p>
      <p style={{ fontSize: 12, color: "var(--color-text-secondary)", margin: 0 }}>— {quote.source}</p>
    </div>
  );
}
