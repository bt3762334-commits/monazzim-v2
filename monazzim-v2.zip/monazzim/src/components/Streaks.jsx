const BADGES = [
  { id: "first",  icon: "⭐", label: "الخطوة الأولى",  desc: "أكمل مهمتك الأولى",       check: (s,d) => d >= 1 },
  { id: "3days",  icon: "🔥", label: "3 أيام متتالية",  desc: "حافظ على streak 3 أيام",  check: (s) => s.count >= 3 },
  { id: "week",   icon: "🏆", label: "بطل الأسبوع",    desc: "7 أيام متتالية",           check: (s) => s.count >= 7 },
  { id: "month",  icon: "💎", label: "الإنجاز العظيم", desc: "30 يوم متتالية",           check: (s) => s.count >= 30 },
  { id: "early",  icon: "🌅", label: "الصباح الباكر",  desc: "ابدأ يومك قبل 8 الصبح",   check: (s,d) => new Date().getHours() < 8 && d >= 1 },
  { id: "focus",  icon: "🎯", label: "التركيز التام",  desc: "أكمل 5 مهام في يوم واحد", check: (s,d) => d >= 5 },
];

export default function Streaks({ streak, completedToday, total, done }) {
  const earned = BADGES.filter(b => {
    if (streak.badges?.includes(b.id)) return true;
    return b.check(streak, completedToday.count);
  });

  const pctDone = total ? Math.round(done/total*100) : 0;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      {/* Streak hero */}
      <div style={{ background: "linear-gradient(135deg, #7F77DD 0%, #534AB7 100%)", borderRadius: 16, padding: 32, display: "flex", alignItems: "center", gap: 24, color: "#fff" }}>
        <div style={{ fontSize: 64, lineHeight: 1 }}>🔥</div>
        <div>
          <div style={{ fontSize: 48, fontWeight: 200, lineHeight: 1, fontVariantNumeric: "tabular-nums" }}>{streak.count}</div>
          <div style={{ fontSize: 16, opacity: 0.9, marginTop: 4 }}>يوم متتالي</div>
          <div style={{ fontSize: 13, opacity: 0.7, marginTop: 6 }}>أكملت {completedToday.count} مهام اليوم</div>
        </div>
        <div style={{ marginRight: "auto", display: "flex", flexDirection: "column", gap: 8 }}>
          <div style={{ fontSize: 13, opacity: 0.8 }}>هدف اليوم: 5 مهام</div>
          <div style={{ width: 160, height: 8, background: "rgba(255,255,255,0.25)", borderRadius: 4, overflow: "hidden" }}>
            <div style={{ height: "100%", width: Math.min(completedToday.count/5*100, 100)+"%", background: "#fff", borderRadius: 4, transition: "width 0.5s" }} />
          </div>
          <div style={{ fontSize: 12, opacity: 0.7 }}>{completedToday.count} / 5 ✅</div>
        </div>
      </div>

      {/* Stats row */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12 }}>
        {[
          { label: "إجمالي الإنجاز", value: pctDone + "%", sub: `${done} من ${total} مهمة`, color: "#1D9E75" },
          { label: "Badges محصّلة",  value: earned.length,  sub: `من ${BADGES.length} badge`,   color: "#7F77DD" },
          { label: "أطول Streak",    value: streak.count + " يوم", sub: "حافظ عليه!", color: "#BA7517" },
        ].map((s, i) => (
          <div key={i} style={{ background: "var(--color-background-primary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: 12, padding: "16px 20px" }}>
            <div style={{ fontSize: 24, fontWeight: 300, color: s.color }}>{s.value}</div>
            <div style={{ fontSize: 13, fontWeight: 500, margin: "4px 0 2px" }}>{s.label}</div>
            <div style={{ fontSize: 11, color: "var(--color-text-secondary)" }}>{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Badges grid */}
      <div style={{ background: "var(--color-background-primary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: 16, padding: 20 }}>
        <h3 style={{ fontSize: 14, fontWeight: 500, margin: "0 0 16px" }}>🏅 الإنجازات والـ Badges</h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))", gap: 10 }}>
          {BADGES.map(b => {
            const unlocked = earned.find(e => e.id === b.id);
            return (
              <div key={b.id} style={{
                padding: "14px 16px", borderRadius: 12, textAlign: "center",
                background: unlocked ? "#EEEDFE" : "var(--color-background-secondary)",
                border: `0.5px solid ${unlocked ? "#7F77DD40" : "var(--color-border-tertiary)"}`,
                opacity: unlocked ? 1 : 0.5, transition: "all 0.3s",
              }}>
                <div style={{ fontSize: 28, marginBottom: 6, filter: unlocked ? "none" : "grayscale(1)" }}>{b.icon}</div>
                <div style={{ fontSize: 12, fontWeight: 500, color: unlocked ? "#3C3489" : "var(--color-text-secondary)", marginBottom: 3 }}>{b.label}</div>
                <div style={{ fontSize: 11, color: "var(--color-text-secondary)", lineHeight: 1.4 }}>{b.desc}</div>
                {unlocked && <div style={{ fontSize: 10, color: "#7F77DD", marginTop: 6, fontWeight: 500 }}>✓ محصّل</div>}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
