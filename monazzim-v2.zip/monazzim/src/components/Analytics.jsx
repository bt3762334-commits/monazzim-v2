export default function Analytics({ tasks, streak, completedToday }) {
  const qs = ["q1","q2","q3","q4"];
  const labels = ["عاجل ومهم","مهم مش عاجل","عاجل مش مهم","مش مهم"];
  const colors = ["#7F77DD","#1D9E75","#BA7517","#888780"];
  const counts = qs.map(q => ({ total: tasks[q]?.length || 0, done: tasks[q]?.filter(t=>t.done).length || 0 }));
  const totalAll = counts.reduce((a,c)=>a+c.total,0);
  const doneAll  = counts.reduce((a,c)=>a+c.done,0);
  const pct = totalAll ? Math.round(doneAll/totalAll*100) : 0;

  // Weekly mock data (replace with real persistence later)
  const weekDays = ["السبت","الأحد","الإثنين","الثلاثاء","الأربعاء","الخميس","الجمعة"];
  const weekData = weekDays.map((d,i) => ({ day: d, done: i === 6 ? completedToday.count : Math.floor(Math.random()*6) }));
  const maxWeek = Math.max(...weekData.map(d=>d.done), 1);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      {/* KPI row */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12 }}>
        {[
          { label: "إجمالي المهام",    value: totalAll,              color: "#7F77DD", icon: "📋" },
          { label: "مكتملة",           value: doneAll,               color: "#1D9E75", icon: "✅" },
          { label: "نسبة الإنجاز",     value: pct + "%",             color: "#BA7517", icon: "📈" },
          { label: "أطول Streak",      value: streak.count + " يوم", color: "#E05C2A", icon: "🔥" },
        ].map((k, i) => (
          <div key={i} style={{ background: "var(--color-background-primary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: 12, padding: "16px 20px" }}>
            <div style={{ fontSize: 22 }}>{k.icon}</div>
            <div style={{ fontSize: 26, fontWeight: 300, color: k.color, margin: "6px 0 2px", fontVariantNumeric: "tabular-nums" }}>{k.value}</div>
            <div style={{ fontSize: 12, color: "var(--color-text-secondary)" }}>{k.label}</div>
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        {/* Quadrant breakdown */}
        <div style={{ background: "var(--color-background-primary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: 16, padding: 20 }}>
          <h3 style={{ fontSize: 14, fontWeight: 500, margin: "0 0 16px" }}>توزيع المهام على المصفوفة</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {counts.map((c, i) => {
              const qPct = c.total ? Math.round(c.done/c.total*100) : 0;
              return (
                <div key={i}>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 4 }}>
                    <span style={{ color: colors[i], fontWeight: 500 }}>Q{i+1} · {labels[i]}</span>
                    <span style={{ color: "var(--color-text-secondary)" }}>{c.done}/{c.total}</span>
                  </div>
                  <div style={{ height: 8, borderRadius: 4, background: "var(--color-background-secondary)", overflow: "hidden" }}>
                    <div style={{ height: "100%", width: qPct+"%", background: colors[i], borderRadius: 4, transition: "width 0.5s ease" }} />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Donut-style summary */}
          <div style={{ marginTop: 20, display: "flex", justifyContent: "center" }}>
            <svg width="120" height="120" viewBox="0 0 120 120">
              {(() => {
                let offset = 0;
                const r = 40, circ = 2*Math.PI*r;
                return counts.map((c, i) => {
                  const frac = totalAll ? c.total/totalAll : 0;
                  const dash = frac * circ;
                  const el = <circle key={i} cx="60" cy="60" r={r} fill="none" stroke={colors[i]} strokeWidth="18"
                    strokeDasharray={`${dash} ${circ-dash}`} strokeDashoffset={-offset} style={{ transform:"rotate(-90deg)", transformOrigin:"60px 60px" }} />;
                  offset += dash;
                  return el;
                });
              })()}
              <text x="60" y="64" textAnchor="middle" style={{ fontSize: 18, fontWeight: 300, fill: "var(--color-text-primary)", fontFamily:"var(--font-sans)" }}>{pct}%</text>
            </svg>
          </div>
        </div>

        {/* Weekly bar chart */}
        <div style={{ background: "var(--color-background-primary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: 16, padding: 20 }}>
          <h3 style={{ fontSize: 14, fontWeight: 500, margin: "0 0 16px" }}>المهام المكتملة (الأسبوع)</h3>
          <div style={{ display: "flex", alignItems: "flex-end", gap: 8, height: 160, paddingBottom: 24, position: "relative" }}>
            {weekData.map((d, i) => {
              const h = (d.done / maxWeek) * 130;
              return (
                <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4, height: "100%", justifyContent: "flex-end" }}>
                  <span style={{ fontSize: 10, color: "var(--color-text-secondary)" }}>{d.done}</span>
                  <div style={{ width: "100%", height: Math.max(h, 4), background: i === 6 ? "#7F77DD" : "var(--color-background-secondary)", borderRadius: 4, border: "0.5px solid var(--color-border-tertiary)", transition: "height 0.5s ease" }} />
                  <span style={{ fontSize: 10, color: i===6 ? "#7F77DD" : "var(--color-text-secondary)", fontWeight: i===6?500:400, position: "absolute", bottom: 0 }}>{d.day.slice(0,2)}</span>
                </div>
              );
            })}
          </div>

          <div style={{ marginTop: 16, padding: "10px 12px", background: "var(--color-background-secondary)", borderRadius: 8, fontSize: 12, color: "var(--color-text-secondary)", lineHeight: 1.6 }}>
            💡 <strong style={{ color: "var(--color-text-primary)" }}>نصيحة:</strong> خليك تركّز على Q2 (مهم مش عاجل) لأنها بتبني المستقبل وغالباً بتتأجّل.
          </div>
        </div>
      </div>
    </div>
  );
}
